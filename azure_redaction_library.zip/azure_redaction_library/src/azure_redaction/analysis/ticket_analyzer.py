"""
End-to-end ticket analyzer.
Orchestrates: Excel Load → Redaction → LLM Analysis
"""

import asyncio
from typing import Optional, List, Dict, Any
from pathlib import Path

from .excel_loader import ExcelLoader
from .redaction_pipeline import RedactionPipeline, TicketRedactionResult
from .llm_analyzer import LLMAnalyzer, AnalysisResult
from ..core.redaction_service import AzureRedactionService


class TicketAnalyzer:
    """
    End-to-end service request ticket analyzer.

    Flow:
    1. Load tickets from Excel
    2. Filter by category/subcategory (optional)
    3. Redact PII using Azure Text Analytics
    4. Analyze redacted data with LLM to find missing information
    5. Return comprehensive results
    """

    def __init__(
        self,
        redaction_service: AzureRedactionService,
        llm_client=None
    ):
        """
        Initialize ticket analyzer.

        Args:
            redaction_service: AzureRedactionService for PII redaction
            llm_client: Your LLM client (optional, configure in LLMAnalyzer)
        """
        self.redaction_service = redaction_service
        self.redaction_pipeline = RedactionPipeline(redaction_service)
        self.llm_analyzer = LLMAnalyzer(llm_client)

        self.excel_loader: Optional[ExcelLoader] = None
        self.redaction_results: List[TicketRedactionResult] = []
        self.analysis_results: List[AnalysisResult] = []

    async def analyze_from_excel(
        self,
        excel_file: str,
        category: Optional[str] = None,
        subcategory: Optional[str] = None,
        max_tickets: Optional[int] = None
    ) -> List[AnalysisResult]:
        """
        Analyze tickets from Excel file (end-to-end).

        Args:
            excel_file: Path to Excel file
            category: Filter by category (optional)
            subcategory: Filter by subcategory (optional)
            max_tickets: Limit number of tickets to analyze (for testing)

        Returns:
            List of AnalysisResult
        """
        print("\n" + "=" * 80)
        print("TICKET ANALYSIS PIPELINE - END TO END")
        print("=" * 80)

        # Step 1: Load Excel
        print("\n[1/3] Loading Excel data...")
        self.excel_loader = ExcelLoader(excel_file)
        tickets = self.excel_loader.get_tickets(category=category, subcategory=subcategory)

        if max_tickets:
            tickets = tickets[:max_tickets]
            print(f"⚠️  Limited to {max_tickets} tickets for analysis")

        if not tickets:
            print("❌ No tickets found matching filters")
            return []

        self.excel_loader.print_summary()

        # Step 2: Redact PII
        print(f"\n[2/3] Redacting PII from {len(tickets)} tickets...")
        print("   Using Azure Text Analytics AI...")

        self.redaction_results = await self.redaction_pipeline.redact_tickets_batch(
            tickets,
            store_tokens=True,
            max_concurrent=10  # Process 10 tickets concurrently
        )

        self.redaction_pipeline.print_redaction_summary(self.redaction_results)

        # Step 3: Analyze with LLM
        print(f"\n[3/3] Analyzing {len(tickets)} tickets with LLM...")
        print("   Finding missing information...")

        redacted_tickets = self.redaction_pipeline.get_redacted_tickets_for_llm(
            self.redaction_results
        )

        self.analysis_results = await self.llm_analyzer.analyze_tickets_batch_async(
            redacted_tickets,
            category_filter=category,
            subcategory_filter=subcategory
        )

        self.llm_analyzer.print_analysis_results(self.analysis_results)

        print("\n" + "=" * 80)
        print("✅ ANALYSIS COMPLETE")
        print("=" * 80)

        return self.analysis_results

    def export_results_to_dict(self) -> Dict[str, Any]:
        """
        Export all results to dictionary for further processing.

        Returns:
            Dictionary with all analysis data
        """
        return {
            "total_tickets": len(self.analysis_results),
            "tickets_with_issues": sum(1 for r in self.analysis_results if r.has_missing_info),
            "average_completeness": sum(r.completeness_score for r in self.analysis_results) / len(self.analysis_results) if self.analysis_results else 0,
            "total_pii_redacted": sum(r.total_pii_found for r in self.redaction_results),
            "detailed_results": [
                {
                    "ticket_id": analysis.ticket_id,
                    "completeness_score": analysis.completeness_score,
                    "has_missing_info": analysis.has_missing_info,
                    "missing_items": [
                        {
                            "field": item.field_name,
                            "severity": item.severity,
                            "issue": item.issue,
                            "suggestion": item.suggestion,
                            "impact": item.impact
                        }
                        for item in analysis.missing_items
                    ],
                    "summary": analysis.analysis_summary,
                    "pii_found": next(
                        (r.total_pii_found for r in self.redaction_results if r.ticket_id == analysis.ticket_id),
                        0
                    )
                }
                for analysis in self.analysis_results
            ]
        }

    def export_results_to_json(self, output_file: str) -> None:
        """
        Export results to JSON file.

        Args:
            output_file: Output JSON file path
        """
        import json

        results = self.export_results_to_dict()

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)

        print(f"\n✅ Results exported to: {output_file}")

    def get_critical_issues(self) -> List[AnalysisResult]:
        """
        Get tickets with critical missing information.

        Returns:
            List of AnalysisResult with critical issues
        """
        critical_tickets = []

        for result in self.analysis_results:
            has_critical = any(
                item.severity == "CRITICAL"
                for item in result.missing_items
            )
            if has_critical:
                critical_tickets.append(result)

        return critical_tickets

    def get_tickets_by_completeness(
        self,
        min_score: float = 0.0,
        max_score: float = 1.0
    ) -> List[AnalysisResult]:
        """
        Get tickets within a completeness score range.

        Args:
            min_score: Minimum completeness score (0.0 to 1.0)
            max_score: Maximum completeness score (0.0 to 1.0)

        Returns:
            List of AnalysisResult in score range
        """
        return [
            result for result in self.analysis_results
            if min_score <= result.completeness_score <= max_score
        ]

    def print_detailed_report(self, ticket_id: str) -> None:
        """
        Print detailed report for a specific ticket.

        Args:
            ticket_id: Ticket ID to report on
        """
        # Find results
        redaction_result = next(
            (r for r in self.redaction_results if r.ticket_id == ticket_id),
            None
        )
        analysis_result = next(
            (r for r in self.analysis_results if r.ticket_id == ticket_id),
            None
        )

        if not redaction_result or not analysis_result:
            print(f"❌ Ticket {ticket_id} not found")
            return

        print("\n" + "=" * 80)
        print(f"DETAILED REPORT - TICKET #{ticket_id}")
        print("=" * 80)

        print(f"\n📊 COMPLETENESS SCORE: {analysis_result.completeness_score:.1%}")
        print(f"🔒 PII ITEMS REDACTED: {redaction_result.total_pii_found}")

        print(f"\n📝 REDACTED TICKET DATA:")
        for field, value in redaction_result.redacted_ticket.items():
            if value and field.startswith("service_req"):
                print(f"\n{field}:")
                print(f"  {str(value)[:200]}...")

        if analysis_result.missing_items:
            print(f"\n⚠️  MISSING INFORMATION ({len(analysis_result.missing_items)} items):")
            for i, item in enumerate(analysis_result.missing_items, 1):
                print(f"\n{i}. [{item.severity}] {item.field_name}")
                print(f"   Issue: {item.issue}")
                print(f"   Suggestion: {item.suggestion}")
                print(f"   Impact: {item.impact}")

        print(f"\n📋 SUMMARY:")
        print(f"  {analysis_result.analysis_summary}")

        print("\n" + "=" * 80)
