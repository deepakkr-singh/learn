"""
Azure Redaction Library
Simplified Azure-only PII redaction library with best practices.

Features:
- Azure Text Analytics AI-powered PII detection
- Low latency with native async support
- Connection pooling and retry logic
- Secure Azure AD authentication
- Simple .env configuration
"""

from .core.redaction_service import AzureRedactionService
from .core.models import RedactionResult, RedactionToken, PIICategory
from .core.config import AzureConfig

__version__ = "1.0.0"
__all__ = [
    "AzureRedactionService",
    "RedactionResult",
    "RedactionToken",
    "PIICategory",
    "AzureConfig",
]
