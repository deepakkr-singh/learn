"""
Redaction pipeline for service request ticket data.
Redacts PII from all text fields before LLM processing.
"""

import asyncio
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from ..core.redaction_service import AzureRedactionService
from ..core.models import RedactionResult


@dataclass
class TicketRedactionResult:
    """Result of redacting a single ticket."""
    ticket_id: str
    original_ticket: Dict[str, Any]
    redacted_ticket: Dict[str, Any]
    redaction_results: Dict[str, RedactionResult] = field(default_factory=dict)
    total_pii_found: int = 0


class RedactionPipeline:
    """
    Pipeline for redacting PII from service request tickets.

    Redacts text from all relevant fields:
    - service_req_description
    - service_req_summary
    - service_req_notes
    - service_req_comments
    - service_req_category (usually safe, but can contain PII)
    - service_req_subcategory (usually safe, but can contain PII)
    """

    TEXT_FIELDS = [
        "service_req_description",
        "service_req_summary",
        "service_req_notes",
        "service_req_comments",
        "service_req_category",
        "service_req_subcategory",
    ]

    def __init__(self, redaction_service: AzureRedactionService):
        """
        Initialize redaction pipeline.

        Args:
            redaction_service: AzureRedactionService instance
        """
        self.redaction_service = redaction_service

    async def redact_ticket(
        self,
        ticket: Dict[str, Any],
        store_tokens: bool = True
    ) -> TicketRedactionResult:
        """
        Redact PII from a single ticket.

        Args:
            ticket: Ticket dictionary
            store_tokens: Whether to store tokens for unmasking

        Returns:
            TicketRedactionResult
        """
        ticket_id = str(ticket.get("service_req_no", "UNKNOWN"))
        redacted_ticket = ticket.copy()
        redaction_results = {}
        total_pii = 0

        # Redact each text field
        for field in self.TEXT_FIELDS:
            text = ticket.get(field, "")

            # Skip empty fields
            if not text or text.strip() == "":
                continue

            # Redact using Azure
            result = await self.redaction_service.redact_async(
                text,
                store_tokens=store_tokens
            )

            # Store results
            redaction_results[field] = result
            redacted_ticket[field] = result.redacted_text
            total_pii += len(result.tokens)

        return TicketRedactionResult(
            ticket_id=ticket_id,
            original_ticket=ticket,
            redacted_ticket=redacted_ticket,
            redaction_results=redaction_results,
            total_pii_found=total_pii,
        )

    async def redact_tickets_batch(
        self,
        tickets: List[Dict[str, Any]],
        store_tokens: bool = True,
        max_concurrent: int = 5
    ) -> List[TicketRedactionResult]:
        """
        Redact PII from multiple tickets in parallel.

        Args:
            tickets: List of ticket dictionaries
            store_tokens: Whether to store tokens for unmasking
            max_concurrent: Max concurrent redaction operations

        Returns:
            List of TicketRedactionResult
        """
        # Use semaphore to limit concurrent operations
        semaphore = asyncio.Semaphore(max_concurrent)

        async def redact_with_semaphore(ticket: Dict[str, Any]) -> TicketRedactionResult:
            async with semaphore:
                return await self.redact_ticket(ticket, store_tokens)

        results = await asyncio.gather(
            *[redact_with_semaphore(ticket) for ticket in tickets]
        )

        return results

    def get_redacted_tickets_for_llm(
        self,
        redaction_results: List[TicketRedactionResult]
    ) -> List[Dict[str, Any]]:
        """
        Extract redacted tickets suitable for LLM processing.

        Args:
            redaction_results: List of TicketRedactionResult

        Returns:
            List of redacted ticket dictionaries
        """
        return [result.redacted_ticket for result in redaction_results]

    def print_redaction_summary(
        self,
        redaction_results: List[TicketRedactionResult]
    ) -> None:
        """Print summary of redaction results."""
        total_tickets = len(redaction_results)
        total_pii = sum(r.total_pii_found for r in redaction_results)
        tickets_with_pii = sum(1 for r in redaction_results if r.total_pii_found > 0)

        print("\n" + "=" * 80)
        print("REDACTION SUMMARY")
        print("=" * 80)
        print(f"📊 Total tickets processed: {total_tickets}")
        print(f"🔒 Total PII items found: {total_pii}")
        print(f"⚠️  Tickets with PII: {tickets_with_pii} ({tickets_with_pii/total_tickets*100:.1f}%)")

        # Field-wise breakdown
        field_pii_counts = {}
        for result in redaction_results:
            for field, redaction_result in result.redaction_results.items():
                field_pii_counts[field] = field_pii_counts.get(field, 0) + len(redaction_result.tokens)

        if field_pii_counts:
            print(f"\n📝 PII by field:")
            for field, count in sorted(field_pii_counts.items(), key=lambda x: x[1], reverse=True):
                print(f"   - {field}: {count} items")

        # Show sample
        if redaction_results:
            print(f"\n📋 Sample redacted ticket (#{redaction_results[0].ticket_id}):")
            sample = redaction_results[0].redacted_ticket
            for field in self.TEXT_FIELDS:
                if field in sample and sample[field]:
                    text = sample[field][:100]
                    print(f"   {field}: {text}...")
