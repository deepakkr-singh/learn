"""
LLM analyzer for finding missing information in service request tickets.
Uses well-crafted prompts to analyze redacted ticket data.
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
import json


@dataclass
class MissingInformation:
    """Information about missing or incomplete data in a ticket."""
    field_name: str
    severity: str  # "critical", "high", "medium", "low"
    issue: str
    suggestion: str
    impact: str


@dataclass
class AnalysisResult:
    """Result of analyzing a ticket for missing information."""
    ticket_id: str
    has_missing_info: bool
    missing_items: List[MissingInformation] = field(default_factory=list)
    completeness_score: float = 0.0  # 0.0 to 1.0
    analysis_summary: str = ""
    raw_llm_response: str = ""


class LLMAnalyzer:
    """
    Analyze service request tickets for missing information using LLM.

    This class generates well-structured prompts and parses LLM responses
    to identify missing or incomplete information in tickets.
    """

    def __init__(self, llm_client=None):
        """
        Initialize LLM analyzer.

        Args:
            llm_client: Your LLM client (e.g., OpenAI, Azure OpenAI, etc.)
                       Set to None if you want to handle LLM calls externally
        """
        self.llm_client = llm_client

    def build_system_prompt(self) -> str:
        """
        Build system prompt for LLM.

        Returns:
            System prompt string
        """
        return """You are an expert service desk analyst specializing in ticket quality assessment.

Your task is to analyze service request tickets and identify missing or incomplete information that could prevent efficient ticket resolution.

Key responsibilities:
1. Identify critical missing information (blocker for resolution)
2. Identify important missing details (slows down resolution)
3. Assess overall ticket completeness
4. Provide actionable suggestions for improvement

Focus areas:
- Problem description clarity and completeness
- Steps to reproduce (if applicable)
- Expected vs actual behavior
- Impact and urgency information
- Environment/system details (if relevant)
- Contact information availability
- Category/subcategory appropriateness

Note: Some fields may contain redacted PII (e.g., [EMAIL_abc123], [PHONE_xyz789]).
Treat these as present information - focus on missing content, not redacted values.

Output format: JSON with structured missing information details."""

    def build_user_prompt(
        self,
        ticket: Dict[str, Any],
        category_filter: Optional[str] = None,
        subcategory_filter: Optional[str] = None
    ) -> str:
        """
        Build user prompt for a specific ticket analysis.

        Args:
            ticket: Ticket dictionary (redacted)
            category_filter: Expected category (if user provided)
            subcategory_filter: Expected subcategory (if user provided)

        Returns:
            User prompt string
        """
        # Extract ticket data
        ticket_id = ticket.get("service_req_no", "UNKNOWN")
        description = ticket.get("service_req_description", "").strip()
        summary = ticket.get("service_req_summary", "").strip()
        notes = ticket.get("service_req_notes", "").strip()
        comments = ticket.get("service_req_comments", "").strip()
        category = ticket.get("service_req_category", "").strip()
        subcategory = ticket.get("service_req_subcategory", "").strip()

        prompt = f"""Analyze the following service request ticket for missing or incomplete information:

**TICKET ID:** {ticket_id}

**TICKET DATA:**

Description:
{description if description else "[EMPTY - CRITICAL ISSUE]"}

Summary:
{summary if summary else "[EMPTY]"}

Internal Notes:
{notes if notes else "[EMPTY]"}

Client Comments:
{comments if comments else "[EMPTY]"}

Category: {category if category else "[NOT SET]"}
Subcategory: {subcategory if subcategory else "[NOT SET]"}
"""

        # Add filter context if provided
        if category_filter or subcategory_filter:
            prompt += "\n**EXPECTED CLASSIFICATION:**\n"
            if category_filter:
                prompt += f"Expected Category: {category_filter}\n"
            if subcategory_filter:
                prompt += f"Expected Subcategory: {subcategory_filter}\n"
            prompt += "\n"

        prompt += """
**ANALYSIS REQUIRED:**

1. Identify all missing or incomplete information
2. Categorize each issue by severity:
   - CRITICAL: Blocks ticket resolution completely
   - HIGH: Significantly delays resolution
   - MEDIUM: Causes minor delays or requires follow-up
   - LOW: Nice to have, minimal impact

3. For each missing item, provide:
   - Field name
   - Specific issue description
   - Actionable suggestion for improvement
   - Impact on ticket resolution

4. Calculate completeness score (0.0 to 1.0)
5. Provide overall assessment summary

**OUTPUT FORMAT (JSON):**

{
  "has_missing_info": true/false,
  "completeness_score": 0.75,
  "missing_items": [
    {
      "field_name": "service_req_description",
      "severity": "CRITICAL",
      "issue": "Specific description of what's missing",
      "suggestion": "Actionable suggestion to fix",
      "impact": "How this affects ticket resolution"
    }
  ],
  "summary": "Brief overall assessment"
}

Analyze now:"""

        return prompt

    async def analyze_ticket_async(
        self,
        ticket: Dict[str, Any],
        category_filter: Optional[str] = None,
        subcategory_filter: Optional[str] = None
    ) -> AnalysisResult:
        """
        Analyze a single ticket for missing information (async).

        Args:
            ticket: Redacted ticket dictionary
            category_filter: Expected category
            subcategory_filter: Expected subcategory

        Returns:
            AnalysisResult
        """
        ticket_id = str(ticket.get("service_req_no", "UNKNOWN"))

        # Build prompts
        system_prompt = self.build_system_prompt()
        user_prompt = self.build_user_prompt(ticket, category_filter, subcategory_filter)

        # Call LLM client (supports both Ollama and OpenAI interfaces)
        if self.llm_client is None:
            # Placeholder for testing without LLM
            llm_response = self._call_llm_placeholder(system_prompt, user_prompt)
        else:
            # Call LLM - supports both Ollama and OpenAI/Azure OpenAI
            response = await self.llm_client.chat_completions_create(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.3
            )

            # Handle both Ollama format {"content": "..."} and OpenAI format
            if isinstance(response, dict) and "content" in response:
                # Ollama format
                llm_response = response["content"]
            else:
                # OpenAI format (response.choices[0].message.content)
                llm_response = response.choices[0].message.content

        # Parse LLM response
        return self._parse_llm_response(ticket_id, llm_response)

    def analyze_ticket(
        self,
        ticket: Dict[str, Any],
        category_filter: Optional[str] = None,
        subcategory_filter: Optional[str] = None
    ) -> AnalysisResult:
        """
        Analyze a single ticket for missing information (sync).

        Args:
            ticket: Redacted ticket dictionary
            category_filter: Expected category
            subcategory_filter: Expected subcategory

        Returns:
            AnalysisResult
        """
        import asyncio
        return asyncio.run(self.analyze_ticket_async(ticket, category_filter, subcategory_filter))

    async def analyze_tickets_batch_async(
        self,
        tickets: List[Dict[str, Any]],
        category_filter: Optional[str] = None,
        subcategory_filter: Optional[str] = None
    ) -> List[AnalysisResult]:
        """
        Analyze multiple tickets in parallel (async).

        Args:
            tickets: List of redacted ticket dictionaries
            category_filter: Expected category
            subcategory_filter: Expected subcategory

        Returns:
            List of AnalysisResult
        """
        import asyncio

        results = await asyncio.gather(
            *[self.analyze_ticket_async(ticket, category_filter, subcategory_filter)
              for ticket in tickets]
        )

        return results

    def _call_llm_placeholder(self, system_prompt: str, user_prompt: str) -> str:
        """
        Placeholder for LLM call when client is not configured.

        Args:
            system_prompt: System prompt
            user_prompt: User prompt

        Returns:
            Mock JSON response
        """
        # Mock response for testing
        return json.dumps({
            "has_missing_info": True,
            "completeness_score": 0.6,
            "missing_items": [
                {
                    "field_name": "service_req_description",
                    "severity": "CRITICAL",
                    "issue": "Description is too vague or empty",
                    "suggestion": "Provide detailed problem description with steps to reproduce",
                    "impact": "Cannot proceed with resolution without understanding the issue"
                }
            ],
            "summary": "Ticket needs more details for efficient resolution"
        })

    def _parse_llm_response(self, ticket_id: str, llm_response: str) -> AnalysisResult:
        """
        Parse LLM JSON response into AnalysisResult.

        Args:
            ticket_id: Ticket ID
            llm_response: Raw LLM response (JSON string)

        Returns:
            AnalysisResult
        """
        try:
            data = json.loads(llm_response)

            # Parse missing items
            missing_items = []
            for item in data.get("missing_items", []):
                missing_items.append(MissingInformation(
                    field_name=item.get("field_name", "unknown"),
                    severity=item.get("severity", "MEDIUM").upper(),
                    issue=item.get("issue", ""),
                    suggestion=item.get("suggestion", ""),
                    impact=item.get("impact", "")
                ))

            return AnalysisResult(
                ticket_id=ticket_id,
                has_missing_info=data.get("has_missing_info", True),
                missing_items=missing_items,
                completeness_score=data.get("completeness_score", 0.0),
                analysis_summary=data.get("summary", ""),
                raw_llm_response=llm_response
            )

        except json.JSONDecodeError as e:
            # Fallback if LLM doesn't return valid JSON
            return AnalysisResult(
                ticket_id=ticket_id,
                has_missing_info=True,
                missing_items=[],
                completeness_score=0.0,
                analysis_summary=f"Error parsing LLM response: {e}",
                raw_llm_response=llm_response
            )

    def print_analysis_results(self, results: List[AnalysisResult]) -> None:
        """Print formatted analysis results."""
        total = len(results)
        with_issues = sum(1 for r in results if r.has_missing_info)
        avg_score = sum(r.completeness_score for r in results) / total if total > 0 else 0

        print("\n" + "=" * 80)
        print("LLM ANALYSIS RESULTS")
        print("=" * 80)
        print(f"📊 Total tickets analyzed: {total}")
        print(f"⚠️  Tickets with issues: {with_issues} ({with_issues/total*100:.1f}%)")
        print(f"📈 Average completeness: {avg_score:.1%}")

        # Severity breakdown
        severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for result in results:
            for item in result.missing_items:
                severity_counts[item.severity] = severity_counts.get(item.severity, 0) + 1

        print(f"\n🚨 Issues by severity:")
        for severity, count in severity_counts.items():
            if count > 0:
                print(f"   {severity}: {count}")

        # Show worst tickets
        worst_tickets = sorted(results, key=lambda r: r.completeness_score)[:3]
        print(f"\n⚠️  Tickets needing most attention:")
        for result in worst_tickets:
            print(f"\n   Ticket #{result.ticket_id} (Score: {result.completeness_score:.1%})")
            print(f"   {result.analysis_summary}")
            for item in result.missing_items[:2]:
                print(f"      - [{item.severity}] {item.field_name}: {item.issue}")
