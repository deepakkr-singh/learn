"""
Azure Redaction Service
Main service for PII redaction using Azure Text Analytics.

Best Practices Implemented:
- Native async support with aiohttp connection pooling
- Automatic retry logic with exponential backoff
- Secure Azure AD authentication
- Low latency with connection reuse
- Batch processing support
- Comprehensive error handling
"""

import asyncio
import hashlib
import time
from typing import List, Optional, Dict, Any
from azure.identity import ClientSecretCredential
from azure.ai.textanalytics.aio import TextAnalyticsClient
from azure.core.exceptions import AzureError

from .models import RedactionResult, RedactionToken, PIICategory
from .config import AzureConfig
from ..utils.retry import RetryHandler


class AzureRedactionService:
    """
    Azure-based PII redaction service using Text Analytics API.

    Features:
    - AI-powered PII detection via Azure Text Analytics
    - Low latency with native async and connection pooling
    - Automatic retry with exponential backoff
    - Batch processing support
    - Token management for unmasking

    Usage:
        # Initialize from .env file
        service = AzureRedactionService.from_env()

        # Redact single text (async)
        result = await service.redact_async("Contact: john@example.com")

        # Redact multiple texts (batch)
        results = await service.redact_batch_async([text1, text2, text3])

        # Unmask redacted text
        original = result.unmask()
    """

    def __init__(self, config: AzureConfig):
        """
        Initialize Azure Redaction Service.

        Args:
            config: AzureConfig instance with credentials
        """
        self.config = config
        self.config.validate()

        # Azure AD credential
        self._credential = ClientSecretCredential(
            tenant_id=config.tenant_id,
            client_id=config.client_id,
            client_secret=config.client_secret,
        )

        # Azure Text Analytics client (lazy initialization)
        self._client: Optional[TextAnalyticsClient] = None

        # Retry handler
        self._retry_handler = RetryHandler(
            max_retries=config.max_retries,
            initial_delay=0.5,
            max_delay=10.0,
        )

        # Token storage for unmasking
        self._token_store: Dict[str, RedactionToken] = {}

    @classmethod
    def from_env(cls, env_path: Optional[str] = None) -> "AzureRedactionService":
        """
        Create service from .env file.

        Args:
            env_path: Optional path to .env file

        Returns:
            AzureRedactionService instance
        """
        config = AzureConfig.from_env(env_path)
        return cls(config)

    def _get_client(self) -> TextAnalyticsClient:
        """
        Get or create Azure Text Analytics client.
        Uses lazy initialization for better performance.

        Returns:
            TextAnalyticsClient instance
        """
        if self._client is None:
            self._client = TextAnalyticsClient(
                endpoint=self.config.text_analytics_endpoint,
                credential=self._credential,
            )
        return self._client

    async def detect_pii(self, text: str) -> List[Dict[str, Any]]:
        """
        Detect PII entities using Azure Text Analytics AI.

        Args:
            text: Text to analyze

        Returns:
            List of detected PII entities with metadata

        Raises:
            AzureError: If Azure API call fails after retries
        """
        if not text:
            return []

        async def _detect():
            client = self._get_client()
            response = await client.recognize_pii_entities(
                documents=[{"id": "1", "language": self.config.language, "text": text}],
                language=self.config.language,
            )

            entities = []
            for doc in response:
                if not doc.is_error:
                    for entity in doc.entities:
                        entities.append({
                            "text": entity.text,
                            "category": entity.category,
                            "subcategory": getattr(entity, "subcategory", None),
                            "confidence_score": entity.confidence_score,
                            "offset": entity.offset,
                            "length": entity.length,
                        })
                else:
                    raise AzureError(f"Azure API error: {doc.error}")

            return entities

        # Use retry handler for robust detection
        return await self._retry_handler.execute_async(_detect)

    async def redact_async(
        self,
        text: str,
        store_tokens: bool = True,
        min_confidence: float = 0.0,
    ) -> RedactionResult:
        """
        Redact PII from text using Azure AI (async).

        Args:
            text: Text to redact
            store_tokens: Whether to store tokens for later unmasking
            min_confidence: Minimum confidence score (0.0 to 1.0)

        Returns:
            RedactionResult with redacted text and tokens
        """
        start_time = time.time()

        if not text:
            return RedactionResult(redacted_text="", tokens=[])

        # Step 1: Detect PII using Azure AI
        entities = await self.detect_pii(text)

        # Filter by confidence
        if min_confidence > 0.0:
            entities = [e for e in entities if e["confidence_score"] >= min_confidence]

        # Step 2: Redact locally based on AI detection
        result = self._redact_with_entities(text, entities)

        # Store tokens if requested
        if store_tokens:
            for token in result.tokens:
                self._token_store[token.token_id] = token

        # Add processing time
        result.processing_time_ms = (time.time() - start_time) * 1000

        return result

    def redact(
        self,
        text: str,
        store_tokens: bool = True,
        min_confidence: float = 0.0,
    ) -> RedactionResult:
        """
        Redact PII from text using Azure AI (sync wrapper).

        Note: This is a sync wrapper around the async method.
        For better performance, use redact_async() directly.

        Args:
            text: Text to redact
            store_tokens: Whether to store tokens for later unmasking
            min_confidence: Minimum confidence score (0.0 to 1.0)

        Returns:
            RedactionResult with redacted text and tokens
        """
        return asyncio.run(self.redact_async(text, store_tokens, min_confidence))

    async def redact_batch_async(
        self,
        texts: List[str],
        store_tokens: bool = True,
        min_confidence: float = 0.0,
        max_concurrent: int = 10,
    ) -> List[RedactionResult]:
        """
        Redact multiple texts in parallel (async).

        Args:
            texts: List of texts to redact
            store_tokens: Whether to store tokens for later unmasking
            min_confidence: Minimum confidence score (0.0 to 1.0)
            max_concurrent: Maximum concurrent requests to Azure

        Returns:
            List of RedactionResults
        """
        if not texts:
            return []

        # Use semaphore to limit concurrent requests
        semaphore = asyncio.Semaphore(max_concurrent)

        async def redact_with_semaphore(text: str) -> RedactionResult:
            async with semaphore:
                return await self.redact_async(text, store_tokens, min_confidence)

        # Process all texts concurrently (with limit)
        results = await asyncio.gather(
            *[redact_with_semaphore(text) for text in texts],
            return_exceptions=False,
        )

        return results

    def redact_batch(
        self,
        texts: List[str],
        store_tokens: bool = True,
        min_confidence: float = 0.0,
        max_concurrent: int = 10,
    ) -> List[RedactionResult]:
        """
        Redact multiple texts in parallel (sync wrapper).

        Note: This is a sync wrapper around the async method.
        For better performance, use redact_batch_async() directly.

        Args:
            texts: List of texts to redact
            store_tokens: Whether to store tokens for later unmasking
            min_confidence: Minimum confidence score (0.0 to 1.0)
            max_concurrent: Maximum concurrent requests to Azure

        Returns:
            List of RedactionResults
        """
        return asyncio.run(
            self.redact_batch_async(texts, store_tokens, min_confidence, max_concurrent)
        )

    def _redact_with_entities(
        self, text: str, entities: List[Dict[str, Any]]
    ) -> RedactionResult:
        """
        Redact text locally based on Azure AI detected entities.

        Args:
            text: Original text
            entities: Detected PII entities from Azure

        Returns:
            RedactionResult with redacted text and tokens
        """
        if not entities:
            return RedactionResult(redacted_text=text, tokens=[], original_text=text)

        # Sort entities by offset in reverse order
        # This allows replacement from end to start without position issues
        sorted_entities = sorted(entities, key=lambda e: e["offset"], reverse=True)

        redacted_text = text
        tokens = []

        for entity in sorted_entities:
            start = entity["offset"]
            end = start + entity["length"]
            original_value = entity["text"]
            category_str = entity["category"]
            subcategory = entity.get("subcategory")
            confidence = entity["confidence_score"]

            # Create unique token ID
            token_id_hash = hashlib.md5(
                f"{original_value}{start}{confidence}".encode()
            ).hexdigest()[:8]

            replacement = f"[{category_str.upper()}_{token_id_hash}]"

            # Map Azure category to PIICategory enum
            category = self._map_azure_category(category_str)

            # Create RedactionToken
            token = RedactionToken(
                token_id=replacement,
                original_value=original_value,
                category=category,
                start_pos=start,
                end_pos=end,
                confidence_score=confidence,
                subcategory=subcategory,
            )
            tokens.append(token)

            # Replace in text
            redacted_text = redacted_text[:start] + replacement + redacted_text[end:]

        return RedactionResult(
            redacted_text=redacted_text,
            tokens=tokens,
            original_text=text,
        )

    def _map_azure_category(self, category: str) -> PIICategory:
        """
        Map Azure PII category string to PIICategory enum.

        Args:
            category: Azure PII category string

        Returns:
            Corresponding PIICategory enum value
        """
        category_map = {
            "Email": PIICategory.EMAIL,
            "PhoneNumber": PIICategory.PHONE,
            "CreditCard": PIICategory.CREDIT_CARD,
            "IPAddress": PIICategory.IP_ADDRESS,
            "Person": PIICategory.PERSON,
            "Organization": PIICategory.ORGANIZATION,
            "Address": PIICategory.ADDRESS,
            "USSocialSecurityNumber": PIICategory.SSN,
            "SSN": PIICategory.SSN,
            "Date": PIICategory.DATE,
            "URL": PIICategory.URL,
            "Passport": PIICategory.PASSPORT,
            "DriverLicense": PIICategory.DRIVER_LICENSE,
            "BankAccount": PIICategory.BANK_ACCOUNT,
        }

        return category_map.get(category, PIICategory.CUSTOM)

    def get_token_map(self) -> Dict[str, str]:
        """
        Get mapping of token IDs to original values.

        Returns:
            Dictionary mapping token IDs to original values
        """
        return {token_id: token.original_value for token_id, token in self._token_store.items()}

    def clear_token_store(self) -> None:
        """Clear the stored tokens."""
        self._token_store.clear()

    async def close(self) -> None:
        """Close Azure client and release connections."""
        if self._client:
            await self._client.close()
            self._client = None

    async def __aenter__(self) -> "AzureRedactionService":
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()
