"""
Excel data loader for service request tickets.
Handles loading and validation of ticket data from Excel files.
"""

import pandas as pd
from typing import Optional, List, Dict, Any
from pathlib import Path


class ExcelLoader:
    """
    Load and validate service request tickets from Excel files.

    Expected columns:
    - service_req_no (required)
    - service_req_description
    - service_req_summary
    - service_req_notes (internal communication)
    - service_req_comments (client-associate communication)
    - service_req_category
    - service_req_subcategory
    """

    REQUIRED_COLUMNS = ["service_req_no"]

    OPTIONAL_COLUMNS = [
        "service_req_description",
        "service_req_summary",
        "service_req_notes",
        "service_req_comments",
        "service_req_category",
        "service_req_subcategory",
    ]

    ALL_COLUMNS = REQUIRED_COLUMNS + OPTIONAL_COLUMNS

    def __init__(self, file_path: str):
        """
        Initialize Excel loader.

        Args:
            file_path: Path to Excel file
        """
        self.file_path = Path(file_path)
        self.df: Optional[pd.DataFrame] = None
        self._validate_file()

    def _validate_file(self) -> None:
        """Validate file exists and is Excel format."""
        if not self.file_path.exists():
            raise FileNotFoundError(f"Excel file not found: {self.file_path}")

        if self.file_path.suffix not in ['.xlsx', '.xls']:
            raise ValueError(f"File must be Excel format (.xlsx or .xls): {self.file_path}")

    def load(self) -> pd.DataFrame:
        """
        Load Excel file and validate columns.

        Returns:
            DataFrame with service request data

        Raises:
            ValueError: If required columns are missing
        """
        # Load Excel
        self.df = pd.read_excel(self.file_path)

        # Validate required columns
        missing_required = [col for col in self.REQUIRED_COLUMNS if col not in self.df.columns]
        if missing_required:
            raise ValueError(
                f"Missing required columns: {missing_required}\n"
                f"Found columns: {list(self.df.columns)}"
            )

        # Add missing optional columns with NaN
        for col in self.OPTIONAL_COLUMNS:
            if col not in self.df.columns:
                self.df[col] = None

        # Fill NaN with empty strings for text processing
        text_columns = [col for col in self.ALL_COLUMNS if col != "service_req_no"]
        self.df[text_columns] = self.df[text_columns].fillna("")

        print(f"✅ Loaded {len(self.df)} tickets from {self.file_path.name}")
        print(f"📋 Available columns: {list(self.df.columns)}")

        return self.df

    def get_tickets(self,
                    category: Optional[str] = None,
                    subcategory: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get tickets as list of dictionaries, optionally filtered.

        Args:
            category: Filter by category (optional)
            subcategory: Filter by subcategory (optional)

        Returns:
            List of ticket dictionaries
        """
        if self.df is None:
            self.load()

        df_filtered = self.df.copy()

        # Apply filters
        if category:
            df_filtered = df_filtered[
                df_filtered['service_req_category'].str.lower() == category.lower()
            ]
            print(f"🔍 Filtered by category '{category}': {len(df_filtered)} tickets")

        if subcategory:
            df_filtered = df_filtered[
                df_filtered['service_req_subcategory'].str.lower() == subcategory.lower()
            ]
            print(f"🔍 Filtered by subcategory '{subcategory}': {len(df_filtered)} tickets")

        # Convert to list of dicts
        tickets = df_filtered.to_dict('records')

        return tickets

    def get_summary(self) -> Dict[str, Any]:
        """
        Get summary statistics of loaded data.

        Returns:
            Dictionary with summary statistics
        """
        if self.df is None:
            self.load()

        summary = {
            "total_tickets": len(self.df),
            "columns": list(self.df.columns),
            "categories": self.df['service_req_category'].value_counts().to_dict() if 'service_req_category' in self.df.columns else {},
            "subcategories": self.df['service_req_subcategory'].value_counts().to_dict() if 'service_req_subcategory' in self.df.columns else {},
            "missing_data": {
                col: int(self.df[col].isna().sum() or (self.df[col] == "").sum())
                for col in self.ALL_COLUMNS if col in self.df.columns
            }
        }

        return summary

    def print_summary(self) -> None:
        """Print formatted summary of loaded data."""
        summary = self.get_summary()

        print("\n" + "=" * 80)
        print("EXCEL DATA SUMMARY")
        print("=" * 80)
        print(f"📊 Total tickets: {summary['total_tickets']}")

        if summary['categories']:
            print(f"\n📂 Categories:")
            for cat, count in summary['categories'].items():
                print(f"   - {cat}: {count} tickets")

        if summary['subcategories']:
            print(f"\n📂 Subcategories:")
            for subcat, count in list(summary['subcategories'].items())[:10]:
                print(f"   - {subcat}: {count} tickets")

        print(f"\n⚠️  Missing/Empty Data:")
        for col, count in summary['missing_data'].items():
            if count > 0:
                pct = (count / summary['total_tickets']) * 100
                print(f"   - {col}: {count} ({pct:.1f}%)")
