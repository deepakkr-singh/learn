"""
Azure Redaction Library - Batch Processing & Low Latency Example
Shows high-performance batch processing with native async (aio) and connection pooling.
"""

import asyncio
import time
import sys
sys.path.insert(0, '../src')

from azure_redaction import AzureRedactionService


async def main():
    """Batch processing with performance metrics."""

    print("=" * 80)
    print("AZURE REDACTION - BATCH PROCESSING & LOW LATENCY")
    print("Uses: azure.ai.textanalytics.aio (native async + connection pooling)")
    print("=" * 80)

    # Initialize service from .env
    async with AzureRedactionService.from_env() as service:

        # Sample texts with PII
        texts = [
            "Contact Alice at alice@company.com or (555) 111-2222",
            "Bob's SSN: 987-65-4321, Card: 4532-1488-0343-6467",
            "Email: carol@corp.com, Phone: 555-333-4444",
            "IP: 192.168.1.100, Support: support@example.com",
            "Credit card: 5425-2334-3010-9903, SSN: 123-45-6789",
        ] * 20  # 100 texts total

        print(f"\n📦 Processing {len(texts)} texts in batch...")
        print(f"⚡ Using max_concurrent=10 for parallel processing\n")

        # Batch processing with timing
        start = time.time()
        results = await service.redact_batch_async(
            texts,
            max_concurrent=10  # 10 concurrent Azure API calls
        )
        total_time = (time.time() - start) * 1000

        # Calculate metrics
        total_pii = sum(len(r.tokens) for r in results)
        avg_time = sum(r.processing_time_ms for r in results) / len(results)
        throughput = len(texts) / (total_time / 1000)

        print("=" * 80)
        print("PERFORMANCE METRICS")
        print("=" * 80)
        print(f"📊 Texts processed:      {len(results)}")
        print(f"🔒 PII items detected:   {total_pii}")
        print(f"⏱️  Avg time per text:    {avg_time:.2f}ms")
        print(f"⚡ Total time:           {total_time:.2f}ms")
        print(f"🚀 Throughput:           {throughput:.2f} texts/sec")

        print("\n" + "=" * 80)
        print("SAMPLE RESULTS (First 3)")
        print("=" * 80)
        for i, result in enumerate(results[:3]):
            print(f"\n📝 Text {i+1}:")
            print(f"   Original: {texts[i]}")
            print(f"   Redacted: {result.redacted_text}")
            print(f"   PII items: {len(result.tokens)} | Time: {result.processing_time_ms:.2f}ms")

        # Category breakdown
        from collections import Counter
        categories = Counter(t.category.value for r in results for t in r.tokens)

        print("\n" + "=" * 80)
        print("PII CATEGORY BREAKDOWN")
        print("=" * 80)
        for category, count in categories.most_common():
            print(f"  {category:25} {count:3} items")

        print("\n✅ Connection pooling: ENABLED (via aio)")
        print("✅ Retry logic: ENABLED (exponential backoff)")
        print("✅ Low latency: ENABLED (native async)")


if __name__ == "__main__":
    asyncio.run(main())
