# Azure Redaction Library (Simplified)

Simple Azure-only PII redaction library with AI-powered detection, low latency, and batch processing.

## ✨ Features

- **AI-Powered**: Azure Text Analytics for accurate PII detection
- **Low Latency**: Native async with `azure.ai.textanalytics.aio` + connection pooling
- **High Performance**: Batch processing with configurable concurrency
- **Auto Retry**: Exponential backoff for transient failures
- **Simple Setup**: Just configure `.env` file with Azure credentials

## 🚀 Quick Start

### 1. Setup Azure

1. Create **Text Analytics** resource in Azure Portal
2. Create **Azure AD App Registration** (service principal)
3. Grant app the **Cognitive Services User** role on Text Analytics resource
4. Copy credentials

### 2. Configure

```bash
cp .env.example .env
```

Edit `.env`:
```env
AZURE_CLIENT_ID=your-client-id
AZURE_TENANT_ID=your-tenant-id
AZURE_CLIENT_SECRET=your-client-secret
AZURE_TEXT_ANALYTICS_ENDPOINT=https://your-resource.cognitiveservices.azure.com/
```

### 3. Install

```bash
pip install -r requirements.txt
```

### 4. Use

```python
import asyncio
import sys
sys.path.insert(0, 'src')

from azure_redaction import AzureRedactionService

async def main():
    async with AzureRedactionService.from_env() as service:
        # Single text
        result = await service.redact_async("Email: john@example.com")
        print(result.redacted_text)

        # Batch processing (low latency!)
        texts = ["Contact: alice@co.com", "Phone: 555-1234"] * 50
        results = await service.redact_batch_async(texts, max_concurrent=10)
        print(f"Processed {len(results)} texts")

asyncio.run(main())
```

## 📊 Performance

- **Native async**: Uses `azure.ai.textanalytics.aio` (not thread pools!)
- **Connection pooling**: Automatic connection reuse
- **Batch processing**: Process 10-50 texts concurrently
- **Typical latency**: 50-200ms per text
- **Throughput**: 30-100 texts/second

## 🎯 Best Practices

**✅ DO:**
- Use `async with` context manager
- Use `redact_batch_async()` for multiple texts
- Set `max_concurrent=10-50` based on load
- Reuse service instance

**❌ DON'T:**
- Use sync methods (`redact()`) in production
- Create new service for each request
- Process texts sequentially

## 📁 Examples

See `examples/batch_example.py` for complete example with metrics.

```bash
cd examples
python batch_example.py
```

## 🔧 Configuration

| Variable | Required | Description |
|----------|----------|-------------|
| `AZURE_CLIENT_ID` | Yes | Azure AD app client ID |
| `AZURE_TENANT_ID` | Yes | Azure AD tenant ID |
| `AZURE_CLIENT_SECRET` | Yes | Azure AD app secret |
| `AZURE_TEXT_ANALYTICS_ENDPOINT` | Yes | Text Analytics endpoint |
| `AZURE_LANGUAGE` | No | Language code (default: `en`) |
| `AZURE_MAX_RETRIES` | No | Max retries (default: `3`) |

## 🏗️ Architecture

```
src/azure_redaction/
├── core/
│   ├── config.py              # .env configuration
│   ├── models.py              # Data models
│   └── redaction_service.py   # Main service (uses aio!)
└── utils/
    └── retry.py               # Retry with exponential backoff
```

**Key Implementation:**
- `TextAnalyticsClient` from `azure.ai.textanalytics.aio` (native async)
- Connection pooling handled by Azure SDK
- Semaphore for concurrent request limiting
- Exponential backoff retry logic

## 📝 License

MIT
