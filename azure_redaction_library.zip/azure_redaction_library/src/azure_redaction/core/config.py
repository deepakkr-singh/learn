"""
Configuration management for Azure redaction library.
Loads credentials from .env file with validation.
"""

import os
from dataclasses import dataclass
from typing import Optional
from dotenv import load_dotenv


@dataclass
class AzureConfig:
    """
    Azure configuration with credentials from .env file.

    Required .env variables:
        AZURE_CLIENT_ID: Azure AD application (service principal) client ID
        AZURE_TENANT_ID: Azure AD tenant ID
        AZURE_CLIENT_SECRET: Azure AD application client secret
        AZURE_TEXT_ANALYTICS_ENDPOINT: Azure Text Analytics endpoint URL

    Example .env:
        AZURE_CLIENT_ID=00000000-0000-0000-0000-000000000000
        AZURE_TENANT_ID=00000000-0000-0000-0000-000000000000
        AZURE_CLIENT_SECRET=your-secret-value
        AZURE_TEXT_ANALYTICS_ENDPOINT=https://your-resource.cognitiveservices.azure.com/
    """

    client_id: str
    tenant_id: str
    client_secret: str
    text_analytics_endpoint: str
    language: str = "en"
    enable_caching: bool = True
    max_retries: int = 3
    timeout_seconds: int = 30

    @classmethod
    def from_env(cls, env_path: Optional[str] = None) -> "AzureConfig":
        """
        Load configuration from .env file.

        Args:
            env_path: Path to .env file (default: looks for .env in current directory)

        Returns:
            AzureConfig instance

        Raises:
            ValueError: If required environment variables are missing
        """
        # Load .env file
        if env_path:
            load_dotenv(env_path)
        else:
            load_dotenv()

        # Get required variables
        client_id = os.getenv("AZURE_CLIENT_ID")
        tenant_id = os.getenv("AZURE_TENANT_ID")
        client_secret = os.getenv("AZURE_CLIENT_SECRET")
        endpoint = os.getenv("AZURE_TEXT_ANALYTICS_ENDPOINT")

        # Validate required variables
        missing_vars = []
        if not client_id:
            missing_vars.append("AZURE_CLIENT_ID")
        if not tenant_id:
            missing_vars.append("AZURE_TENANT_ID")
        if not client_secret:
            missing_vars.append("AZURE_CLIENT_SECRET")
        if not endpoint:
            missing_vars.append("AZURE_TEXT_ANALYTICS_ENDPOINT")

        if missing_vars:
            raise ValueError(
                f"Missing required environment variables: {', '.join(missing_vars)}\n"
                f"Please add them to your .env file. See README for details."
            )

        # Get optional variables
        language = os.getenv("AZURE_LANGUAGE", "en")
        enable_caching = os.getenv("AZURE_ENABLE_CACHING", "true").lower() == "true"
        max_retries = int(os.getenv("AZURE_MAX_RETRIES", "3"))
        timeout_seconds = int(os.getenv("AZURE_TIMEOUT_SECONDS", "30"))

        return cls(
            client_id=client_id,
            tenant_id=tenant_id,
            client_secret=client_secret,
            text_analytics_endpoint=endpoint.rstrip("/"),
            language=language,
            enable_caching=enable_caching,
            max_retries=max_retries,
            timeout_seconds=timeout_seconds,
        )

    def validate(self) -> None:
        """
        Validate configuration values.

        Raises:
            ValueError: If configuration is invalid
        """
        if not self.client_id or len(self.client_id) < 10:
            raise ValueError("Invalid AZURE_CLIENT_ID")

        if not self.tenant_id or len(self.tenant_id) < 10:
            raise ValueError("Invalid AZURE_TENANT_ID")

        if not self.client_secret or len(self.client_secret) < 10:
            raise ValueError("Invalid AZURE_CLIENT_SECRET")

        if not self.text_analytics_endpoint.startswith("https://"):
            raise ValueError("AZURE_TEXT_ANALYTICS_ENDPOINT must start with https://")

        if self.max_retries < 0 or self.max_retries > 10:
            raise ValueError("max_retries must be between 0 and 10")

        if self.timeout_seconds < 1 or self.timeout_seconds > 300:
            raise ValueError("timeout_seconds must be between 1 and 300")

    def __repr__(self) -> str:
        """Safely represent config without exposing secrets."""
        return (
            f"AzureConfig("
            f"client_id='{self.client_id[:8]}...', "
            f"tenant_id='{self.tenant_id[:8]}...', "
            f"endpoint='{self.text_analytics_endpoint}', "
            f"language='{self.language}')"
        )
