"""
Retry handler with exponential backoff.
Best practice for handling transient Azure API failures.
"""

import asyncio
import time
from typing import TypeVar, Callable, Awaitable
from azure.core.exceptions import (
    AzureError,
    ServiceRequestError,
    ServiceResponseError,
)

T = TypeVar("T")


class RetryHandler:
    """
    Retry handler with exponential backoff for Azure API calls.

    Features:
    - Exponential backoff with jitter
    - Configurable max retries
    - Only retries transient errors (network, throttling)
    - Does not retry authentication errors
    """

    def __init__(
        self,
        max_retries: int = 3,
        initial_delay: float = 0.5,
        max_delay: float = 10.0,
        backoff_factor: float = 2.0,
    ):
        """
        Initialize retry handler.

        Args:
            max_retries: Maximum number of retry attempts
            initial_delay: Initial delay in seconds
            max_delay: Maximum delay in seconds
            backoff_factor: Exponential backoff multiplier
        """
        self.max_retries = max_retries
        self.initial_delay = initial_delay
        self.max_delay = max_delay
        self.backoff_factor = backoff_factor

    def _should_retry(self, error: Exception) -> bool:
        """
        Determine if error is retryable.

        Args:
            error: Exception to check

        Returns:
            True if error should be retried
        """
        # Retry transient errors
        retryable_errors = (
            ServiceRequestError,  # Network errors
            ServiceResponseError,  # 5xx errors, throttling
        )

        if isinstance(error, retryable_errors):
            return True

        # Retry on generic Azure errors (may be transient)
        if isinstance(error, AzureError):
            error_msg = str(error).lower()
            # Common transient error indicators
            transient_indicators = [
                "timeout",
                "throttl",
                "rate limit",
                "service unavailable",
                "internal server error",
                "503",
                "429",
            ]
            return any(indicator in error_msg for indicator in transient_indicators)

        return False

    def _calculate_delay(self, attempt: int) -> float:
        """
        Calculate delay for next retry with exponential backoff.

        Args:
            attempt: Current attempt number (0-indexed)

        Returns:
            Delay in seconds
        """
        delay = self.initial_delay * (self.backoff_factor ** attempt)
        # Cap at max_delay
        delay = min(delay, self.max_delay)
        # Add jitter (randomness) to avoid thundering herd
        import random
        jitter = random.uniform(0, 0.1 * delay)
        return delay + jitter

    async def execute_async(
        self, func: Callable[[], Awaitable[T]]
    ) -> T:
        """
        Execute async function with retry logic.

        Args:
            func: Async function to execute

        Returns:
            Result from function

        Raises:
            Exception: If all retries exhausted or non-retryable error
        """
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                return await func()
            except Exception as e:
                last_error = e

                # Don't retry if not retryable
                if not self._should_retry(e):
                    raise

                # Don't retry if this was the last attempt
                if attempt >= self.max_retries:
                    break

                # Calculate delay and wait
                delay = self._calculate_delay(attempt)
                print(
                    f"[RetryHandler] Attempt {attempt + 1} failed: {e}. "
                    f"Retrying in {delay:.2f}s..."
                )
                await asyncio.sleep(delay)

        # All retries exhausted
        raise last_error

    def execute(self, func: Callable[[], T]) -> T:
        """
        Execute sync function with retry logic.

        Args:
            func: Sync function to execute

        Returns:
            Result from function

        Raises:
            Exception: If all retries exhausted or non-retryable error
        """
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                return func()
            except Exception as e:
                last_error = e

                # Don't retry if not retryable
                if not self._should_retry(e):
                    raise

                # Don't retry if this was the last attempt
                if attempt >= self.max_retries:
                    break

                # Calculate delay and wait
                delay = self._calculate_delay(attempt)
                print(
                    f"[RetryHandler] Attempt {attempt + 1} failed: {e}. "
                    f"Retrying in {delay:.2f}s..."
                )
                time.sleep(delay)

        # All retries exhausted
        raise last_error
