"""
End-to-End Ticket Analysis Example
Complete pipeline: Excel → Redaction → LLM Analysis

Shows how to analyze service request tickets for missing information
while protecting sensitive PII data.
"""

import asyncio
import sys
import httpx
sys.path.insert(0, '../src')

from azure_redaction import AzureRedactionService
from azure_redaction.analysis import TicketAnalyzer


# =============================================================================
# OLLAMA LLM CLIENT (for local testing)
# Replace with OpenAI/Azure OpenAI in production
# =============================================================================

class OllamaClient:
    """
    Simple Ollama client for local LLM testing.

    REPLACE THIS WITH OPENAI IN PRODUCTION:

    from openai import AsyncOpenAI
    llm_client = AsyncOpenAI(
        api_key="your-api-key",
        base_url="https://api.openai.com/v1"  # or your Azure OpenAI endpoint
    )
    """

    def __init__(self, model="gpt-oss:20b", base_url="http://localhost:11434"):
        self.model = model
        self.base_url = base_url

    async def chat_completions_create(self, messages, temperature=0.3):
        """
        Ollama-compatible chat completion.
        API matches OpenAI format for easy replacement.
        """
        # Combine system and user messages for Ollama
        prompt = ""
        for msg in messages:
            if msg["role"] == "system":
                prompt += f"<|system|>\n{msg['content']}\n\n"
            elif msg["role"] == "user":
                prompt += f"<|user|>\n{msg['content']}\n\n<|assistant|>\n"

        async with httpx.AsyncClient(timeout=300.0) as client:  # 5 min timeout for large models
            response = await client.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": temperature,
                        "num_predict": 2000,
                    }
                }
            )

            if response.status_code == 200:
                result = response.json()
                return {"content": result.get("response", "")}
            else:
                raise Exception(f"Ollama error: {response.status_code} - {response.text}")


# =============================================================================
# OPENAI WRAPPER (for production use)
# =============================================================================

class OpenAIClientWrapper:
    """
    Wrapper for OpenAI/Azure OpenAI to match the expected interface.

    Usage:
        from openai import AsyncOpenAI
        openai_client = AsyncOpenAI(api_key="sk-...")
        llm_client = OpenAIClientWrapper(openai_client, model="gpt-4o")
    """

    def __init__(self, openai_client, model="gpt-4o"):
        self.client = openai_client
        self.model = model

    async def chat_completions_create(self, messages, temperature=0.3):
        """
        OpenAI-compatible chat completion.
        Wraps OpenAI's response to match our interface.
        """
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
            response_format={"type": "json_object"}  # Force JSON output
        )
        # Convert to our format
        return {"content": response.choices[0].message.content}


async def main():
    """Run end-to-end ticket analysis."""

    print("=" * 80)
    print("SERVICE REQUEST TICKET ANALYSIS")
    print("End-to-End: Excel → Redaction → LLM Analysis")
    print("=" * 80)

    # =========================================================================
    # STEP 1: Initialize Azure Redaction Service
    # =========================================================================
    print("\n[SETUP] Initializing Azure Redaction Service...")

    async with AzureRedactionService.from_env() as redaction_service:

        # =====================================================================
        # STEP 2: Initialize LLM Client
        # =====================================================================
        print("[SETUP] Initializing LLM Client...")

        # OPTION 1: Use Ollama (local testing) - CURRENTLY ACTIVE
        llm_client = OllamaClient(model="gpt-oss:20b")
        print("   Using Ollama (gpt-oss:20b) on localhost:11434")

        # OPTION 2: Use OpenAI (production) - UNCOMMENT TO USE
        # from openai import AsyncOpenAI
        # openai_client = AsyncOpenAI(api_key="your-api-key")
        # llm_client = OpenAIClientWrapper(openai_client, model="gpt-4o")
        # print("   Using OpenAI GPT-4")

        # OPTION 3: Use Azure OpenAI (production) - UNCOMMENT TO USE
        # from openai import AsyncAzureOpenAI
        # azure_openai = AsyncAzureOpenAI(
        #     api_key="your-azure-openai-key",
        #     api_version="2024-02-01",
        #     azure_endpoint="https://your-resource.openai.azure.com"
        # )
        # llm_client = OpenAIClientWrapper(azure_openai, model="gpt-4o")
        # print("   Using Azure OpenAI")

        # OPTION 4: Mock (no real LLM) - UNCOMMENT TO USE
        # llm_client = None
        # print("   Using Mock LLM (testing only)")

        # =====================================================================
        # STEP 3: Initialize Ticket Analyzer
        # =====================================================================
        analyzer = TicketAnalyzer(
            redaction_service=redaction_service,
            llm_client=llm_client
        )

        # =====================================================================
        # STEP 4: Run Analysis
        # =====================================================================

        # SCENARIO 1: Analyze all tickets in Excel
        print("\n" + "=" * 80)
        print("SCENARIO 1: Analyze All Tickets")
        print("=" * 80)

        results = await analyzer.analyze_from_excel(
            excel_file="examples/sample_tickets.xlsx",  # Your Excel file
            max_tickets=5  # Limit for demo (remove in production)
        )

        # =====================================================================
        # SCENARIO 2: Analyze tickets by category
        # =====================================================================
        # Uncomment to use:
        # print("\n" + "=" * 80)
        # print("SCENARIO 2: Analyze by Category")
        # print("=" * 80)
        #
        # results = await analyzer.analyze_from_excel(
        #     excel_file="sample_tickets.xlsx",
        #     category="Technical Support",  # Filter by category
        #     max_tickets=10
        # )

        # =====================================================================
        # SCENARIO 3: Analyze by category + subcategory
        # =====================================================================
        # Uncomment to use:
        # print("\n" + "=" * 80)
        # print("SCENARIO 3: Analyze by Category + Subcategory")
        # print("=" * 80)
        #
        # results = await analyzer.analyze_from_excel(
        #     excel_file="sample_tickets.xlsx",
        #     category="Technical Support",
        #     subcategory="Network Issues",
        #     max_tickets=10
        # )

        # =====================================================================
        # STEP 5: Get Insights
        # =====================================================================

        print("\n" + "=" * 80)
        print("ANALYSIS INSIGHTS")
        print("=" * 80)

        # Find critical issues
        critical_tickets = analyzer.get_critical_issues()
        print(f"\n🚨 Tickets with CRITICAL issues: {len(critical_tickets)}")
        for ticket in critical_tickets[:3]:
            print(f"   - Ticket #{ticket.ticket_id}: {ticket.analysis_summary}")

        # Find incomplete tickets (< 60% complete)
        incomplete_tickets = analyzer.get_tickets_by_completeness(
            min_score=0.0,
            max_score=0.6
        )
        print(f"\n⚠️  Incomplete tickets (<60%): {len(incomplete_tickets)}")

        # Find well-formed tickets (> 80% complete)
        good_tickets = analyzer.get_tickets_by_completeness(
            min_score=0.8,
            max_score=1.0
        )
        print(f"\n✅ Well-formed tickets (>80%): {len(good_tickets)}")

        # =====================================================================
        # STEP 6: Export Results
        # =====================================================================

        print("\n" + "=" * 80)
        print("EXPORT RESULTS")
        print("=" * 80)

        # Export to JSON
        analyzer.export_results_to_json("analysis_results.json")

        # Get as dictionary for programmatic access
        results_dict = analyzer.export_results_to_dict()
        print(f"\n📊 Summary:")
        print(f"   Total tickets: {results_dict['total_tickets']}")
        print(f"   With issues: {results_dict['tickets_with_issues']}")
        print(f"   Avg completeness: {results_dict['average_completeness']:.1%}")
        print(f"   Total PII redacted: {results_dict['total_pii_redacted']}")

        # =====================================================================
        # STEP 7: Detailed Report for Specific Ticket
        # =====================================================================

        if results:
            print("\n" + "=" * 80)
            print("SAMPLE DETAILED REPORT")
            print("=" * 80)

            # Show detailed report for first ticket
            first_ticket_id = results[0].ticket_id
            analyzer.print_detailed_report(first_ticket_id)

    print("\n" + "=" * 80)
    print("✅ ANALYSIS COMPLETE!")
    print("=" * 80)


# =============================================================================
# CUSTOMIZATION GUIDE
# =============================================================================
"""
TO USE WITH YOUR LLM:

1. Install your LLM client library:
   pip install openai  # For OpenAI
   # OR
   pip install anthropic  # For Claude
   # OR other LLM provider

2. Configure your LLM client in STEP 2 above:

   For OpenAI:
   ```python
   from openai import AsyncOpenAI
   llm_client = AsyncOpenAI(api_key="sk-...")
   ```

   For Azure OpenAI:
   ```python
   from openai import AsyncAzureOpenAI
   llm_client = AsyncAzureOpenAI(
       api_key=os.getenv("AZURE_OPENAI_KEY"),
       api_version="2024-02-01",
       azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
   )
   ```

   For Anthropic Claude:
   ```python
   from anthropic import AsyncAnthropic
   llm_client = AsyncAnthropic(api_key="sk-ant-...")
   ```

3. Update LLMAnalyzer to call your LLM:

   Edit: src/azure_redaction/analysis/llm_analyzer.py
   In analyze_ticket_async() method, replace the TODO section with:

   For OpenAI-style:
   ```python
   response = await self.llm_client.chat.completions.create(
       model="gpt-4o",
       messages=[
           {"role": "system", "content": system_prompt},
           {"role": "user", "content": user_prompt}
       ],
       temperature=0.3,
       response_format={"type": "json_object"}
   )
   llm_response = response.choices[0].message.content
   ```

   For Claude:
   ```python
   response = await self.llm_client.messages.create(
       model="claude-3-5-sonnet-20241022",
       max_tokens=2000,
       system=system_prompt,
       messages=[{"role": "user", "content": user_prompt}]
   )
   llm_response = response.content[0].text
   ```

4. Create sample Excel file with columns:
   - service_req_no
   - service_req_description
   - service_req_summary
   - service_req_notes
   - service_req_comments
   - service_req_category
   - service_req_subcategory

5. Run this script:
   python ticket_analysis_example.py
"""


if __name__ == "__main__":
    asyncio.run(main())
