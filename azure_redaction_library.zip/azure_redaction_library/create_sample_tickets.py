"""
Create sample service request tickets Excel file for testing.
"""

import pandas as pd
from pathlib import Path

# Sample ticket data with PII
tickets_data = [
    {
        "service_req_no": "SR-2024-001",
        "service_req_description": "User John Smith (john.smith@acme.com) is unable to access the VPN. His phone number is (555) 123-4567. He gets error code 403 when trying to connect from IP 192.168.1.100.",
        "service_req_summary": "VPN access denied for user",
        "service_req_notes": "Internal: User's account shows active. SSN on file: 123-45-6789. Need to check firewall rules.",
        "service_req_comments": "Client says: I've been trying since morning. My manager Alice Johnson (alice@acme.com) also facing same issue. Our credit card ending in 4467 was charged for VPN subscription.",
        "service_req_category": "Network",
        "service_req_subcategory": "VPN Issues"
    },
    {
        "service_req_no": "SR-2024-002",
        "service_req_description": "Email not working",
        "service_req_summary": "",  # Empty - missing info!
        "service_req_notes": "",  # Empty - missing info!
        "service_req_comments": "Help!!! Email broken!!!",  # Vague - missing details!
        "service_req_category": "Email",
        "service_req_subcategory": ""  # Empty - missing info!
    },
    {
        "service_req_no": "SR-2024-003",
        "service_req_description": "Employee Sarah Wilson (sarah.wilson@company.com, phone: 555-987-6543) reported that the application crashes when clicking 'Submit' button on the payment form. This happens consistently. Steps to reproduce: 1) Login to portal 2) Navigate to Payments 3) Fill form with credit card 4532-1488-0343-6467 4) Click Submit. Expected: Payment processes. Actual: Application crashes with error 'NullPointerException at line 234'.",
        "service_req_summary": "Application crash on payment submission",
        "service_req_notes": "Internal: Reproduced in test environment. User SSN 987-65-4321 verified. Assigned to dev team. Critical issue affecting all users trying to make payments.",
        "service_req_comments": "Customer says: This is urgent! We have clients waiting. Contact me at sarah.wilson@company.com or call (555) 987-6543. My manager Bob Davis (bob@company.com) is also aware and expects quick resolution.",
        "service_req_category": "Application",
        "service_req_subcategory": "Payment Module"
    },
    {
        "service_req_no": "SR-2024-004",
        "service_req_description": "Printer not working in office",
        "service_req_summary": "Printer issue",
        "service_req_notes": "",  # Empty
        "service_req_comments": "",  # Empty - no client communication!
        "service_req_category": "Hardware",
        "service_req_subcategory": "Printer"
    },
    {
        "service_req_no": "SR-2024-005",
        "service_req_description": "",  # CRITICAL - completely empty!
        "service_req_summary": "",
        "service_req_notes": "Internal note: User called from (555) 111-2222. Email: michael@corp.com",
        "service_req_comments": "",
        "service_req_category": "",  # Missing!
        "service_req_subcategory": ""
    },
    {
        "service_req_no": "SR-2024-006",
        "service_req_description": "User Emma Thompson (emma.thompson@enterprise.com) needs access to shared drive \\\\server\\finance. She requires read/write permissions for folders: Q1_Reports, Q2_Reports. Her employee ID is EMP-123456. Manager approval received from David Miller (david@enterprise.com). Urgency: High - needed for quarterly audit starting Monday.",
        "service_req_summary": "Shared drive access request",
        "service_req_notes": "Verified with HR. Employee status: Active. Department: Finance. Start date: 2024-01-15. Background check completed. Manager confirmation email attached.",
        "service_req_comments": "Emma says: Hi, I need access to finance shared drive ASAP for the audit. My colleague Lisa (lisa@enterprise.com, 555-333-4444) also needs same access. Please expedite. Thanks!",
        "service_req_category": "Access Management",
        "service_req_subcategory": "File Share Access"
    },
    {
        "service_req_no": "SR-2024-007",
        "service_req_description": "System slow",
        "service_req_summary": "Performance issue",
        "service_req_notes": "User mentioned something about slowness",
        "service_req_comments": "System is slow sometimes",  # Very vague!
        "service_req_category": "Performance",
        "service_req_subcategory": "General"
    },
    {
        "service_req_no": "SR-2024-008",
        "service_req_description": "User account locked for Robert Chen (robert.chen@startup.com, SSN: 456-78-9012). User reports trying to login 3 times with correct password but account got locked. Last successful login was yesterday at 3:45 PM from IP 10.0.0.50. User needs urgent access for critical client presentation in 2 hours. Contact: (555) 777-8888.",
        "service_req_summary": "Account lockout - urgent",
        "service_req_notes": "Internal: Account locked due to 3 failed attempts from IP 203.45.67.89 (suspicious - not user's usual IP). Security team notified. Need to verify user identity before unlocking. Credit card on file: 5425-2334-3010-9903.",
        "service_req_comments": "Robert: Please unlock ASAP! I have client demo in 2 hours. I was using correct password. My manager Jennifer (jennifer@startup.com) can confirm. Call me at 555-777-8888 immediately!",
        "service_req_category": "Security",
        "service_req_subcategory": "Account Management"
    },
    {
        "service_req_no": "SR-2024-009",
        "service_req_description": "Need software installed",  # Missing: which software?
        "service_req_summary": "",
        "service_req_notes": "User called, needs some software",
        "service_req_comments": "Can you install the software? Thanks.",  # No specifics!
        "service_req_category": "Software",
        "service_req_subcategory": ""
    },
    {
        "service_req_no": "SR-2024-010",
        "service_req_description": "Database connection timeout error occurring on production server DB-PROD-01 for application CustomerPortal. Error started at 2024-01-15 09:30 AM EST. Affects all users trying to access customer records. Error message: 'Connection timeout after 30 seconds'. Database server IP: 172.16.0.100. Application server: APP-01 (172.16.0.50). No recent changes to infrastructure. 500+ users impacted.",
        "service_req_summary": "Production database timeout - critical",
        "service_req_notes": "Internal: DBA team investigating. Initial check shows high CPU usage (95%) on DB server. No failed jobs. Transaction log size normal. Suspect query performance issue. Contacted by IT Manager Tom Wilson (tom@company.com, 555-999-0000). Priority: P1 - Production down.",
        "service_req_comments": "Operations team reporting: Customer complaints increasing. Revenue impact estimated at $10K/hour. Need immediate resolution. Contact ops lead Sarah at sarah.ops@company.com or 555-888-7777. CEO asking for updates every 30 mins.",
        "service_req_category": "Infrastructure",
        "service_req_subcategory": "Database"
    }
]

# Create DataFrame
df = pd.DataFrame(tickets_data)

# Save to Excel
output_path = Path("examples/sample_tickets.xlsx")
output_path.parent.mkdir(exist_ok=True)

df.to_excel(output_path, index=False, engine='openpyxl')

print(f"✅ Created sample Excel file: {output_path}")
print(f"📊 Total tickets: {len(df)}")
print(f"\n📋 Ticket categories:")
print(df['service_req_category'].value_counts())
print(f"\n⚠️  Tickets with missing data (for testing):")
print(f"   - SR-2024-002: Missing summary, notes, subcategory, vague description")
print(f"   - SR-2024-004: Missing notes and comments")
print(f"   - SR-2024-005: Almost completely empty (CRITICAL)")
print(f"   - SR-2024-007: Vague description, minimal details")
print(f"   - SR-2024-009: Missing software name, no details")
print(f"\n✅ Good tickets (for comparison):")
print(f"   - SR-2024-001: Network/VPN - complete info")
print(f"   - SR-2024-003: Application - very detailed")
print(f"   - SR-2024-006: Access Management - well documented")
print(f"   - SR-2024-008: Security - urgent but complete")
print(f"   - SR-2024-010: Infrastructure - comprehensive details")
print(f"\nNote: All tickets contain PII (emails, phones, SSNs, credit cards)")
print("This PII will be redacted before LLM analysis!")
