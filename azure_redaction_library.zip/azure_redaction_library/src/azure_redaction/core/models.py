"""
Data models for Azure redaction library.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional


class PIICategory(Enum):
    """PII categories supported by Azure Text Analytics."""
    EMAIL = "Email"
    PHONE = "PhoneNumber"
    SSN = "USSocialSecurityNumber"
    CREDIT_CARD = "CreditCard"
    IP_ADDRESS = "IPAddress"
    PERSON = "Person"
    ORGANIZATION = "Organization"
    ADDRESS = "Address"
    DATE = "Date"
    URL = "URL"
    PASSPORT = "Passport"
    DRIVER_LICENSE = "DriverLicense"
    BANK_ACCOUNT = "BankAccount"
    CUSTOM = "Custom"


@dataclass
class RedactionToken:
    """
    Represents a redacted PII token.

    Attributes:
        token_id: Unique identifier for the redacted token
        original_value: The original PII value
        category: PII category (e.g., Email, Phone, SSN)
        start_pos: Start position in original text
        end_pos: End position in original text
        confidence_score: Confidence score from Azure AI (0.0 to 1.0)
        subcategory: Optional subcategory from Azure
    """
    token_id: str
    original_value: str
    category: PIICategory
    start_pos: int
    end_pos: int
    confidence_score: float = 0.0
    subcategory: Optional[str] = None

    def __repr__(self) -> str:
        return (f"RedactionToken(token_id='{self.token_id}', "
                f"category={self.category.value}, "
                f"confidence={self.confidence_score:.2f})")


@dataclass
class RedactionResult:
    """
    Result of a redaction operation.

    Attributes:
        redacted_text: Text with PII redacted
        tokens: List of RedactionToken objects
        original_text: Original text (optional, for debugging)
        processing_time_ms: Processing time in milliseconds
    """
    redacted_text: str
    tokens: List[RedactionToken] = field(default_factory=list)
    original_text: Optional[str] = None
    processing_time_ms: float = 0.0

    def __repr__(self) -> str:
        return (f"RedactionResult(tokens={len(self.tokens)}, "
                f"time={self.processing_time_ms:.2f}ms)")

    def get_tokens_by_category(self, category: PIICategory) -> List[RedactionToken]:
        """Get all tokens of a specific category."""
        return [token for token in self.tokens if token.category == category]

    def unmask(self) -> str:
        """
        Unmask the redacted text back to original.

        Returns:
            Original text with PII restored
        """
        if not self.tokens:
            return self.redacted_text

        result = self.redacted_text
        # Sort tokens by start position in reverse to maintain positions
        sorted_tokens = sorted(self.tokens, key=lambda t: t.start_pos, reverse=True)

        for token in sorted_tokens:
            result = result.replace(token.token_id, token.original_value, 1)

        return result
